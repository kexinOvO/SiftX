"""Delocate commands package."""
